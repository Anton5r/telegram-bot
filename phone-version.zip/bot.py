import os 
from time import *
import terminal_banner
import telebot
import traceback
import config_bot as cfgb
from emoji import emojize
from tqdm import tqdm
from datetime import datetime

# Начала
os.system(r'clear')
banner_text = "Бот запущен в Бета-тест\n Версия v3.0"
my_banner = terminal_banner.Banner(banner_text)
print(my_banner)

cur_date = datetime.now().strftime("%Y-%m-%d")
cur_time = datetime.now().time()

ADMIN = 993251034
API_TOKEN = (cfgb.api_token)
db = telebot.TeleBot(API_TOKEN)

@db.message_handler(commands=['start'])
def start_message(message):
    db.send_message(message.chat.id,"Привет")
    db.send_sticker(message.chat.id, 'CAACAgIAAxkBAAEENupiNrgHfkaJk2XuxuLlfidpsXSoMgACjQUAAsEYngsKx0_eFeeGMSME')
    db.send_message(message.chat.id, "Команды:\n Поик на YouTube - /search_videos\n Раписание - /rasp\n Объявление - /news\n Поиск по Википедии - /wiki\n Ссылка на проект - /github\n")
    print(message.chat.id)
    
    id = message.chat.id

    with open('list.txt', 'a') as file:
        file.write(f'user_id: {id} - {cur_time} - {cur_date}\n')
    
    # Приер для созадание клавы
# def start_message(message):
    # keyboard = telebot.types.ReplyKeyboardMarkup(True)
    # keyboard.row('Привет', 'Пока')
    # bot.send_message(message.chat.id, 'Привет!', reply_markup=keyboard)

    
@db.message_handler(commands=["help"])
def help_message(message):
    db.send_message(message.chat.id, "Команды:\n Поик на YouTube - /search_videos\n Ссылки на сайт(для конр. точек инфа для них) - /link\n Раписание - /rasp\n Объявление - /news\n Поиск по Википедии - /wiki\n Ссылка на проект - /github\n")

@db.message_handler(commands=["link"])
def link_messange(messange):
    db.send_message(messange.chat.id, "полезные ссылки на конр. точки: " + "http://bit.ly/3trIV7i")

@db.message_handler(commands=["github"])
def handle_github(message):
    db.send_message(message.chat.id, 'Ссылка: ' + 'https://github.com/Anton5r?tab=repositories')

@db.message_handler(commands=["rasp"])
def parser_message(message):
    os.system(r'python parser_bot.py')
    db.send_message(message.chat.id, f'Расписание-{cur_date}: https://bit.ly/3CTdJAG')
    db.send_message(message.chat.id, 'Если ссылка старая или устарела, то файл с постоянно новой и рабочей ссылкой')
    db.send_document(message.chat.id, open(file=f'link-{cur_date}.txt', mode='rb'))
    traceback.print_exc()


@db.message_handler(commands=["news"])
def news_message(message):
    db.send_sticker(message.chat.id, 'CAACAgIAAxkBAAEEN3ViNxtbkeEenP62YKh-s6nEd69ZeAACjwUAAsEYngtFfm89RZ0YiSME')
    db.send_message(message.chat.id, "Ссылка на расписание меняется каждую неделю в субботу или если есть изменения. Если у вас возникли проблемы с командой /search_videos, то она допиливается или времено не работает")

#Wki 
@db.message_handler(commands=['wiki'])
def wikipedia(message):
    msg_wiki = db.send_message(message.chat.id, 'Отправьте мне любое слово, и я найду его значение на Wikipedia')
    db.register_next_step_handler(msg_wiki, wiki_search)

def wiki_search(message):
    db.send_sticker(message.chat.id, 'CAACAgIAAxkBAAEEN3diNxuOv1IIegcI6_MmaayPhdFZHQACqgUAAsEYnguRQsJfsHcFPyME')
    db.send_message(message.chat.id, 'Начинаю поиск')
    import wiki_bot
    db.send_message(message.chat.id, wiki_bot.getwiki(message.text))


@db.message_handler(content_types=["text"])
def handle_text(message):
    db.send_sticker(message.chat.id, 'CAACAgIAAxkBAAEEN3tiNxzj16Tq9S3fn5VsA6b-1lV4mAACoQUAAsEYngspY3PpJLX0DCME')
    db.send_message(message.chat.id, 'Я не понимаю о чём вы сенпай(нуна)')
    
# Тут сразу запуск бота и парсера# Сарт бота
while True:
    try:    
        db.polling(none_stop=True)

    except Exception as e:
        traceback.print_exc()  # или просто print(e) если у вас логгера нет,
        # или import traceback; traceback.print_exc() для печати полной инфы
        sleep(1)
