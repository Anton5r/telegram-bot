#!/bin/sh

echo 'Установка компанентов для бота'

apt update -y
apt upgare -y 

python intall.py