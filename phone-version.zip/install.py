import os
import time
import traceback

os.system(r'clear')

def install():
    
    print('Щас будет установака библеотек для Бота\n')
    print('На какую систему устанаваливаем?: Arch linux(pacman) или Ubuntu(apt)\n')

    a = input('Для выбора напишите 1 или 2: ')

    if a == '1':
        print('\nБудет выполнено установака на arch\n')
        os.system(r'sudo pacman -Syyuu')
        os.system(r'sudo pacman -S python')
        os.system(r'sudo pacman -S geckodriver')

        print('\nЩас будет устанавливаться pip пакеты\n')
        pip()
        reboot()
        
    elif a == '2':
        print('\nБудет выполнено установака на linux основаном на debian\n')
        os.system(r'apt update -y && apt upgrade -y')
        os.system(r'apt install python3 ')
        
        print('\nТут должна быть ссылка на бот в github\n')
        print('\nЩас будет устанавливаться pip пакеты\n')
        pip()
        reboot()
        
    else:
        print('Такого варианта нет')
        return install()

def pip():
    os.system(r'python -m pip install --upgrade pip')
    os.system(r'pip install terminal_banner')
    os.system(r'pip install pyTelegramBotAPI')
    os.system(r'pip install --upgrade pyTelegramBotAPI')
    os.system(r'pip install emoji')
    os.system(r'pip install tqdm')
    os.system(r'pip install aiogram')
    os.system(r'pip install traceback2')
    os.system(r'pip install bs4')
    os.system(r'pip install requests')
    os.system(r'pip install selenium')
    os.system(r'pip install wikipedia')
    os.system(r'pip install wikipediaapi')
    os.system(r'pip install logging')
    
    
def reboot():
    r = str(input('Установка завершена. Перезапустить пк?: Да или Нет'))
                     
    if r == '1) да':
        print('Выполняю')
        os.system(r'reboot')
    elif r == '1':
        print('Выполняю')
        os.system(r'reboot')
    elif r == '2) нет':
        print('Хорошо')
    elif r == '2':
        print('Ладно')
    else:
        print('Такого варианта нет. :(')
        return reboot()
    
while True:
    try:
        install()
        exit()

    except Exception as e:
        traceback.print_exc()  # или просто print(e) если у вас логгера нет,
            # или import traceback; traceback.print_exc() для печати полной инфы
        time.sleep(2)
